<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
* Contiene datos de integración para realizar pruebas de conectividad
* */
return $integration_default = array(

/**
* Llave Privada
* */
"private_key" => "-----BEGIN RSA PRIVATE KEY-----"
    . "<br/>MIIEowIBAAKCAQEAv/O1Eg0fT1FfYsb76Z1qLbALJD04MSW16lq/wI15w3OfET7m"
    . "<br/>t71uw8NxaqcbTR2WJPZcA9qmTVGnr/AqKGSsRPJHWJF2PKxoJ6a+n8BDD2dI3HN9"
    . "<br/>LMIk2wO134iY+u38MgZUkn3FuoMzDD6BIiz7BjUZB0JafGDU5W8C3fMG2hGH8QfA"
    . "<br/>jIwR7mH5fRO8s4INU54S0BjdY7CPNcqRsaa7fOoKWJpzcdnrN2/5Zm/h3unps8PP"
    . "<br/>A6rdwMO0lWoawmpJQGD5XLp3cX/UZsF0GSmLcoVhm48/YuVOnfOxVp29HGQ773c7"
    . "<br/>NyWHRJwBTfAtIYKL6gSgJc5jZQHRxoXwM8YE5QIDAQABAoIBACVDt8xYVdK9Nmpj"
    . "<br/>vPYehEV4XsFbTTRlYMqtcXp9PL1QDfp4HqxfD0jcAYG2DVvMOaDVXwm0ggKSrp4+"
    . "<br/>XsDWwobkDivImY6v3cyM14cF+T7dS0zY8t0kl6kZME7EIwbb+tDvX63M0v0hiWCA"
    . "<br/>JeuvldAfsMsy+4QX/FzKT2EtVBAzbsE0qamQqbl43cyiPDsMLqAJMIDy9j0t1xeC"
    . "<br/>dxpwbie2tWGx7ugidlJMwaJr3INcXXjaP2mTpwKgysyoytgZawfwLb+MyylOdO8y"
    . "<br/>BNni4n5aaQ0fCR37Vzia0UtIHKX3K2/mvGisPyU6j0c61budzlKmJoUG235JAbVM"
    . "<br/>/q0nXiECgYEA70lcypqicWOID7DuEAXckYEp10O9xipS5j5A9WUAJSzLkwHmGx+B"
    . "<br/>VojM7HZZ6IG/CQRu+nBM1M4QhU6/Y9YdQ6R++TjgfYD5Xj4A16HsaYkZhrZWQ/zP"
    . "<br/>zxwECyyRWHjMobSKVEl/Is7mSRW8FY3wTdrXep391IeD+mtTu0KPa+kCgYEAzVv2"
    . "<br/>zLE3h6uJOPGNLg0ILxierVmfDkmaGSJ8GNSZDcnvPXuKLee3mnELeuVPpG21nZjS"
    . "<br/>UenECWzg/d6rXk/qNHGLPrOqb6VHvUtH8cLCJSBaivbEMdiQQKFicRAVh4wnpBFk"
    . "<br/>X+NGQfufDZjsTQyRf8ka+VIvPLpuP2A2VQMev50CgYBJDXSuxhbh1ykq4TFM4v07"
    . "<br/>ztsfRSci4Lj+YfMi9/rbXpmn/+RoU24BJTKq3lcEjNftwNTA0JgkP+T7TddQe4Xj"
    . "<br/>qMy6+YpPxphbFULckirC7YBFiFU93Gj1KfByGOEmyXpvw9aXdPjDf7b+iQwq6HJ8"
    . "<br/>0lsGrEVaJSU9xpaBjQiMQQKBgQCniPFNiP5+hmkKtbWx7hvRIErDravfYhh/jOyk"
    . "<br/>7Tx4TVgKVrEiRjo5myP8fPt+b6qNCdH71bSC4/qh4nj4FkZBxqgM3VKchsCCI9pr"
    . "<br/>17G/zCdR24OwDreQopjHGJIX5TWp2i6DM81rozXdR/bv3OMO1yhUYsH6zzWGKp3o"
    . "<br/>uQTq2QKBgGALx25/VEtPTIuSMTLi3BPuq2kUhDH2v7NVpc/v0LUhe2n6D9859PcZ"
    . "<br/>m9ZEpytw0hCOr4P4/noExGps6r2YvAuv+pOWuKge9zc8d4UXHGI5OgItGPtTvluG"
    . "<br/>T/5PE6a8VBdidJUU5qgTCiRYm4FV4ckBXRixWDpqtDJupZtIIp10"
    . "<br/>-----END RSA PRIVATE KEY-----",

/**
* Certificado Publico
* */
"public_cert" => "-----BEGIN CERTIFICATE-----"
    . "<br/>MIIDODCCAiACCQDwn5MgehPx2TANBgkqhkiG9w0BAQsFADBeMQswCQYDVQQGEwJD"
    . "<br/>TDETMBEGA1UECAwKU29tZS1TdGF0ZTERMA8GA1UEBwwIU0FOVElBR08xEDAOBgNV"
    . "<br/>BAoMB0FsbHdhcmUxFTATBgNVBAMMDDU5NzAyMDAwMDE5NTAeFw0xNTA4MDUxNTIz"
    . "<br/>MDZaFw0xNjA4MDQxNTIzMDZaMF4xCzAJBgNVBAYTAkNMMRMwEQYDVQQIDApTb21l"
    . "<br/>LVN0YXRlMREwDwYDVQQHDAhTQU5USUFHTzEQMA4GA1UECgwHQWxsd2FyZTEVMBMG"
    . "<br/>A1UEAwwMNTk3MDIwMDAwMTk1MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC"
    . "<br/>AQEAv/O1Eg0fT1FfYsb76Z1qLbALJD04MSW16lq/wI15w3OfET7mt71uw8Nxaqcb"
    . "<br/>TR2WJPZcA9qmTVGnr/AqKGSsRPJHWJF2PKxoJ6a+n8BDD2dI3HN9LMIk2wO134iY"
    . "<br/>+u38MgZUkn3FuoMzDD6BIiz7BjUZB0JafGDU5W8C3fMG2hGH8QfAjIwR7mH5fRO8"
    . "<br/>s4INU54S0BjdY7CPNcqRsaa7fOoKWJpzcdnrN2/5Zm/h3unps8PPA6rdwMO0lWoa"
    . "<br/>wmpJQGD5XLp3cX/UZsF0GSmLcoVhm48/YuVOnfOxVp29HGQ773c7NyWHRJwBTfAt"
    . "<br/>IYKL6gSgJc5jZQHRxoXwM8YE5QIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQCLz9yu"
    . "<br/>a2hWb1AOwsxTuYOJJV64dXn+wjhV0I9u2igWm/9ntUqIPUEGD9kSB03Xb7KpAFuL"
    . "<br/>VFaIO9gbUk4ejxAidOAH/svU5+VAExtxYOvZ2gVlerJFi4xsOREnVj58vVUoWBtJ"
    . "<br/>twH61E9nrqV5vy3mdqBkRaaNi8drftL4haRLZYu2PIc4FyCQsbGBCOtQo/KFzCte"
    . "<br/>jbqaKcRz9w94v0w4i2TS2CtcHwHzjyzA9WI1RfOmgK5AVCuVcZq4mFstP4xbW5WK"
    . "<br/>aTchi23Ljrxb3DSLMn+/2QioU2oJw0no7X+cHTnae/4NkrIhhCUkirh2lPvN+lnq"
    . "<br/>+wXInipi/W/aYgbG<br/>-----END CERTIFICATE-----",

/**
* Certificado Privado
* */
"webpay_cert" => "-----BEGIN CERTIFICATE-----"
    . "<br/>MIIFhTCCA20CBFOF3SIwDQYJKoZIhvcNAQEFBQAwgYYxIDAeBgkqhkiG9w0BCQEW"
    . "<br/>EWpjZXJkYUBleHBlcnRpLmNsMQswCQYDVQQGEwJDTDERMA8GA1UECAwIU2FudGlh"
    . "<br/>Z28xETAPBgNVBAcMCFNhbnRpYWdvMRAwDgYDVQQKDAdFeHBlclRJMRAwDgYDVQQL"
    . "<br/>DAdFeHBlclRJMQswCQYDVQQDDAIxMDAeFw0xNDA1MjgxMjU3MDZaFw0xNjA1Mjcx"
    . "<br/>MjU3MDZaMIGGMSAwHgYJKoZIhvcNAQkBFhFqY2VyZGFAZXhwZXJ0aS5jbDELMAkG"
    . "<br/>A1UEBhMCQ0wxETAPBgNVBAgMCFNhbnRpYWdvMREwDwYDVQQHDAhTYW50aWFnbzEQ"
    . "<br/>MA4GA1UECgwHRXhwZXJUSTEQMA4GA1UECwwHRXhwZXJUSTELMAkGA1UEAwwCMTAw"
    . "<br/>ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCX1t11QZSgfodg+NPwKdof"
    . "<br/>lakbpxsFmCvjbY3Vpp6/bTv56XIZe/Z3gBlU4zeGslEaqzs1k4cGAcdZPHxSMydC"
    . "<br/>oLxmyXpdS2hVFUZTYAeanXHhQzUKmNlgYj3uObprPEEQzD/vEuqpwz2/ZGyaHsWs"
    . "<br/>exu9aeuLAUUSNne0yqobrzRfEp2FqCp4sJB80cXgGfPA4Cr5jROHqUi8sVWpWRy5"
    . "<br/>ai5ZaiXRPo3YKF1336twuw9lRS3cRtJh9/AoJElGT7G7BMDpxyTTa08y1iRliDGu"
    . "<br/>mwWivQMHoKqEs0lCtF9Uz8cFdmiIoRPTt6McpmLoapL9v19xjNnim4lke6DPvtcg"
    . "<br/>uato7T+frDqA5Cj5GRP/8jbe90Y+YjHuJTkw+fkV6gDTRmJ3wCWDIw/07aY6nZ+H"
    . "<br/>24Imu6N2YBsMEsa8j9OW04mNgtppRC4dFBh0FIKXC35kJgN38y+6T7MsQThX1XZS"
    . "<br/>SlK0FygJJADVGelmxtsrRRfnp4yLYRjwdkRGExRjVs/+fkOyKI+fX0o68z6MEDyA"
    . "<br/>5epVHpgwJ/Yz3Lo7cgXy0hO5a/MfZc0Y0ofb29g8sJMJ8j/SSR85i4pFxudn+HH0"
    . "<br/>SmkkzE/P10adF/X+pqjscOE+aXwnX09lUUQ9TIlpYaR3hUhONsuefYJ2sHz2z+vt"
    . "<br/>K5btQwN7u9+QeXLgb20PMwIDAQABMA0GCSqGSIb3DQEBBQUAA4ICAQAqCepOSFi7"
    . "<br/>8d6lKTfWpMuj5ygpplBa3Bj81AKkNfSGDN7zkNX2sCbqn9aEjniIPtldG6I2fgCs"
    . "<br/>FYTZE9oEPNiuEuH7PNtAjTExIUi9Jzm7bqjCdSs7Ioek1cPePgst017zJ6NSTkaM"
    . "<br/>r7pUDaS3855xO92uaJskppAeegwz9Dv3d5wY+wVViqUki4pZyxa95IvBJz4NR1Xr"
    . "<br/>cO6XtUUT9M0wbd0jAkRp7DPQfkihZj8vLSvlUYTRdlF2swIBE/ME2T3NCa0/kt1c"
    . "<br/>IA1Aq/zn7t0yKvyaJ/O//LrHA1Lfa/uC61O/9P3t+eXDsYl73CeGQdSYZp2DAZmA"
    . "<br/>Ek3tzwhFa6HR+POIo8MptWMT3DQ0ISHH+EW1Xp8GHIGsk2ELsXuA6XTNwpfz9yvl"
    . "<br/>9d7IGsq4cdX88cNUCbXm4tj7F3s6i8pNWeCImaYcXKGCBdsLM+lbmqbuV7o3d1Ei"
    . "<br/>efbR1TQkCxRBNCMUI0pF7NW8PvY3QER9/jEnN52SX+tuQRVdpgl+PyTdSASr4FhV"
    . "<br/>+HHmgeOgeOewXDnZ7aA1F6f8+CY8Niv4FGZIAptdxTqdynY4nUy/wFowBouO3LEF"
    . "<br/>6nIcQ3Jx1pDXoEmcLa03JaL7qQNSHyqSe/YEl8E5fdDr7vApzw9pvpAjj1aslidL"
    . "<br/>bNd4l1YGlL2vbGsIXZlbdBLiblXRi78AyQ=="
    . "<br/>-----END CERTIFICATE-----",

/**
* Codigo Comercio
* */
"commerce_code" => "597020000195",

);
