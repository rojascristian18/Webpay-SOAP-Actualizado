<?php
require_once('anulacion-webpay.php');
require_once('anulacion-config.php');


class AnulacionSoap{	

	var $config;
	var $AnulacionWebpay;

	function __construct($params){
		$this->config = new AnulacionConfig($params);
		$this->AnulacionWebpay = new AnulacionWebpay($this->config);
    }

    public function anularPedido ($authorizationCode, $authorizedAmount, $buyOrder, $nullifyAmount ) 
	{
		try {

			$error = array();

			$nullificationInput = new nullificationInput();

			$nullificationInput->authorizationCode = $authorizationCode;
			$nullificationInput->commerceId = $this->config->getParam('CODIGO_COMERCIO');
			$nullificationInput->buyOrder = $buyOrder;
			$nullificationInput->authorizedAmount = intval($authorizedAmount);
			$nullificationInput->nullifyAmount = intval($nullifyAmount);

			$error['input'] = $nullificationInput;

			$nullificationOutput = $this->AnulacionWebpay->nullify(
				array( 'nullificationInput' => $nullificationInput )
			);

			$xmlResponse = $this->soapClient->__getLastResponse();
			$soapValidation = new SoapValidation($xmlResponse, $this->config->getParam("WEBPAY_CERT"));
			$validationResult = $soapValidation->getValidationResult();

			if ($validationResult === TRUE){
				$nullificationOutput = $this->AnulacionWebpay->nullify(
					array( 'nullificationInput' => $nullificationInput )
				);				
		    }
		    else{				
				$error["error"] = "Error validando conexión a Webpay";
				$error["detail"] = "No se puede validar la respuesta usando certificado " . WebPaySOAP::getConfig("WEBPAY_CERT");				
		    }

		} catch (Exception $e) {
			$error["error"] = "Error conectando a Webpay";
			$error["detail"] = $e->getMessage();
		}

		return $error;
	}
    
}

?>
